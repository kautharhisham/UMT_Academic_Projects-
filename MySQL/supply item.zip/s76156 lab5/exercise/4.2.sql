SELECT A.suppid, B.suppaddid, B.addr1, B.city, B.postcode, B.state
FROM supplier AS A
INNER JOIN  supplieraddress AS B
ON A.suppid = B.suppid
AND A.suppid = 300001;                                 
