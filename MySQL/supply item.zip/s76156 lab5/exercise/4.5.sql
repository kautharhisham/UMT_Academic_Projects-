SELECT A.suppid, A.suppname, B.itmcode, C.itmdesc, B.lastdatesupply
FROM supplier AS A
INNER JOIN itemsupplier AS B
USING (suppid)
INNER JOIN item AS C
USING (itmcode)
WHERE A.suppid = 300005;
