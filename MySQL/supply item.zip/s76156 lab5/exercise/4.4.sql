SELECT A.iccode, A.icdescription, B.itmcode, B.itmdesc, B.reorderqty
FROM itemcategory AS A
LEFT OUTER JOIN item AS B
ON A.iccode = B.iccode;
