INSERT INTO itemcategory(icdescription) VALUES('Groceries');
INSERT INTO itemcategory(icdescription) VALUES('Home Appliances');
INSERT INTO itemcategory(icdescription) VALUES('Electronics');
INSERT INTO itemcategory(icdescription) VALUES('Fashion');
INSERT INTO itemcategory(icdescription) VALUES('Health & Beauty');

INSERT INTO item VALUES('E10020', 'Axus Tablet 7 Inch', 103, 8, 3, 10);
INSERT INTO item VALUES('G11250', 'Milo Packet 3 in 1', 101, 50, 10, 150);
INSERT INTO item VALUES('G11315', 'Seri Murni Cooking Oil', 101, 150, 20, 1000);
INSERT INTO item VALUES('G11146', 'Heinz Apple Cider', 101, 10, 3, 10);
INSERT INTO item VALUES('E10067', 'Xiomi Mi Pad', 103, 4, 2, 5);
INSERT INTO item VALUES('H20113', 'AX Stand Mixer', 102, 4, 4, 20);
INSERT INTO item VALUES('H21121', 'PN Air Fryer', 102, 5, 2, 5);
INSERT INTO item VALUES('F35354', 'Men Canvas Jogging Shoes', 104, 10, 5, 15);
INSERT INTO item VALUES('H21345', 'Pomade Hair Cream', 185, 10, 5, 25);
INSERT INTO item VALUES('F12912', 'Cartoon T-Shirt', 104, 20, 5, 20);

INSERT INTO supplier(suppname, suppemail, suppofficeno, supphpno) 
VALUES('CCM Supplier Sdn Bhd', 'service@ccm.com.my', '03-5521010', '019-5562021');
INSERT INTO supplier(suppname, suppemail, suppofficeno, supphpno) 
VALUES('Vantage Sdn Bhd', 'vantage@gmail.com', '09-9983435', '013-9521718');
INSERT INTO supplier(suppname, suppemail, suppofficeno, supphpno) 
VALUES('Arena Supplier Sdn Bhd', 'arena2yahoo.com.my', '03-9257875', '011-3325480');
INSERT INTO supplier(suppname, suppemail, suppofficeno, supphpno) 
VALUES('Outlet Sdn Bhd', 'outlet01@gmail.com', '04-5516780', '012-6656878');
INSERT INTO supplier(suppname, suppemail, suppofficeno, supphpno) 
VALUES('Ntt Supply Sdn Bhd', 'sales@ntt.com.my', '09-5578000', '016-2202030');

INSERT INTO itemsupplier
VALUES('E10020', 300002, 80, '2015-08-10', '2016-06-24', 800.00, 5, 10, 50);
INSERT INTO itemsupplier
VALUES('E10020', 300003, 100, '2015-10-23', '2016-08-05', 750.00, 2, 5, 150);
INSERT INTO itemsupplier
VALUES('E10020', 300004, 90, '2015-10-30', '2016-09-02', 760.00, 5, 10, 100);
INSERT INTO itemsupplier
VALUES('G11250', 300001, 2500, '2015-04-16', '2016-09-18', 12.00, 0, 100, 1000);
INSERT INTO itemsupplier
VALUES('G11250', 300003, 1800, '2015-03-08', '2016-09-10', 12.50, 0, 80, 1000);
INSERT INTO itemsupplier
VALUES('G11315', 300001, 4500, '2015-02-15', '2016-09-12', 13.00, 0, 100, 1000);
INSERT INTO itemsupplier
VALUES('G11315', 300004, 3000, '2015-03-26', '2016-08-14', 12.50, 0, 150, 1100);
INSERT INTO itemsupplier
VALUES('G11146', 300001, 3000, '2015-06-20', '2016-09-02', 18.80, 0, 100, 250);
INSERT INTO itemsupplier
VALUES('E10067', 300002, 40, '2015-04-01', '2016-06-10', 900.00, 5, 3, 5);
INSERT INTO itemsupplier
VALUES('E10067', 300005, 15, '2015-04-01', '2016-06-10', 1000.00, 3, 3, 5);

INSERT INTO itemstock VALUES('E10020', '2016-03-15', 124, 'Closed');
INSERT INTO itemstock VALUES('E10020', '2016-08-02', 590, 'Opened');
INSERT INTO itemstock VALUES('G11250', '2016-04-14', 1100, 'Opened');
INSERT INTO itemstock VALUES('G11315', '2016-04-16', 1200, 'Closed');
INSERT INTO itemstock VALUES('G11315', '2016-06-10', 1600, 'Opened');
INSERT INTO itemstock VALUES('G11416', '2016-02-15', 678, 'Opened');
INSERT INTO itemstock VALUES('E10067', '2016-05-26', 100, 'Opened');
INSERT INTO itemstock VALUES('H20113', '2016-08-14', 60, 'Opened');
INSERT INTO itemstock VALUES('H21121', '2016-04-12', 150, 'Opened');
INSERT INTO itemstock VALUES('f35354', '2016-07-04', 100, 'Opened');

INSERT INTO supplieraddress(suppid, addr1, city, postcode, state)
VALUES(300001, 'Lot 5, Tmn Perindustrian B. Raja', 'Klang', 42800, 'Selangor');
INSERT INTO supplieraddress(suppid, addr1, city, postcode, state)
VALUES(300002, '167, Tmn Shamelin Perkasa', 'Cheras', 43200, 'Kuala Lumpur');
INSERT INTO supplieraddress(suppid, addr1, city, postcode, state)
VALUES(300003, 'Block AE, Pasir Gudang Trade Zone', 'Pasir Gudang', 81700, 'Johor');
INSERT INTO supplieraddress(suppid, addr1, city, postcode, state)
VALUES(300004, 'JB Free Trade Zone', 'J. Bahru', 81100, 'Johor');
INSERT INTO supplieraddress(suppid, addr1, city, postcode, state)
VALUES(300005, 'Lot 45, Solok 2/24 Prai', 'Prai', 13700, 'Penang');

