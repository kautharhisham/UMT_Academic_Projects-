SELECT A.suppaddid, A.suppid, A.addr1, A.state
FROM supplieraddress AS A
INNER JOIN supplieraddress AS B
ON A.state = B.state
AND A.suppaddid <> B.suppaddid
ORDER BY A.state, A.suppid;