SELECT A.itmcode, A.itmdesc, B.stkcountdate
FROM item AS A
INNER JOIN itemstock AS B
ON A.itmcode = B.itmcode
AND B.stkcountstatus = 'Opened'
AND A.itmcode LIKE '%G%';
