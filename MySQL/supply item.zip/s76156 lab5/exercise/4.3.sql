SELECT A.suppid, C.suppname, B.itmcode, B.itmdesc, A.lastdatesupply
FROM itemsupplier AS A
RIGHT OUTER JOIN item AS B
ON A.itmcode = B.itmcode
INNER JOIN supplier AS C
ON A.suppid = C.suppid;