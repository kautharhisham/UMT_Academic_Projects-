SELECT A.itmcode AS ProductCode, A.itmdesc AS ProductName,
		B.qtystock AS StockOnHand
FROM item AS A
INNER JOIN itemstock AS B
ON A.itmcode = B.itmcode
INNER JOIN itemcategory AS C
USING (iccode)
WHERE C.icdescription = 'Home Appliances';
