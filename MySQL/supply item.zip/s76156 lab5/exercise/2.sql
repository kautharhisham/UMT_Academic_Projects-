CREATE DATABASE MYLAB5;

USE MYLAB5;
CREATE TABLE itemcategory (
iccode			INT(3) AUTO_INCREMENT,
icdescription	VARCHAR(30),
CONSTRAINT itemcategory_iccode_pk PRIMARY KEY(iccode)
);

ALTER TABLE itemcategory AUTO_INCREMENT = 101;

CREATE TABLE item (
itmcode			VARCHAR(40),
itmdesc			VARCHAR(50),
iccode			INT(3),
avgmthlyusage	INT,
reorderlevel	INT,
reorderqty		INT,
CONSTRAINT item_itmcode_pk PRIMARY KEY(itmcode)
);

CREATE TABLE supplier (
suppid			INT(6) AUTO_INCREMENT, 
suppname		VARCHAR(50), 
suppemail		VARCHAR(30), 
suppofficeno	VARCHAR(20), 
supphpno		VARCHAR(20),
CONSTRAINT supplier_suppid_pk PRIMARY KEY(suppid)
);
ALTER TABLE supplier AUTO_INCREMENT = 300001;

CREATE TABLE itemsupplier (
itmcode				VARCHAR(40),
suppid				INT(6),
totqtysupptodate	INT, 
firstdatesupply		DATE, 
lastdatesupply		DATE, 
stdprice			DECIMAL(9,2),
discount			INT, 
minorderqty			INT, 
maxorderqty			INT,
CONSTRAINT item_itmcodesuppid_pk UNIQUE(itmcode, suppid),
CONSTRAINT itemsupplier_itmcode_fk FOREIGN KEY(itmcode) REFERENCES item(itmcode),
CONSTRAINT itemsupplier_suppid_fk FOREIGN KEY(suppid) REFERENCES supplier(suppid)
);

CREATE TABLE itemstock (
itmcode			VARCHAR(40),
stkcountdate	DATE NOT NULL, 
qtystock		INT NOT NULL, 
stkcountstatus	VARCHAR(15) CHECK (stkcountstatus IN ('Closed', 'Open')),
CONSTRAINT itemstock_itmcodestkcountdate_pk PRIMARY KEY(itmcode, stkcountdate),
CONSTRAINT itemstock_itmcode_fk FOREIGN KEY(itmcode) REFERENCES item(itmcode)
);

CREATE TABLE supplieraddress (
suppaddid		INT(4) AUTO_INCREMENT, 
suppid			INT(6), 
addr1			VARCHAR(50), 
city			VARCHAR(30), 
postcode		INT(5), 
state			VARCHAR(30),
CONSTRAINT supplieraddress_suppaddid_pk PRIMARY KEY(suppaddid),
CONSTRAINT supplieraddress_suppid_fk FOREIGN KEY(suppid) REFERENCES supplier(suppid)
);

ALTER TABLE supplieraddress AUTO_INCREMENT = 2001;