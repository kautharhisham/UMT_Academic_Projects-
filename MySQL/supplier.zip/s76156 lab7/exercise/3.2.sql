SELECT A.trxno, A.trxdate, A.trxrefno
FROM inventorytrx AS A
WHERE NOT EXISTS (SELECT repOrderNo
					FROM replenishmentorder
                    WHERE repOrderNo = A.trxrefno
                    AND supplierNo <> 1003
                    );