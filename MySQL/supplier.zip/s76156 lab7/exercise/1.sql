DROP DATABASE IF EXISTS lab7;
CREATE DATABASE lab7;
USE lab7;

CREATE TABLE supplier (
supplierNo  INT(4) AUTO_INCREMENT,
supplierName VARCHAR(50),
CONSTRAINT supplier_supplierNo_pk PRIMARY KEY(supplierNo)
);

ALTER TABLE SUPPLIER AUTO_INCREMENT = 1000;

CREATE TABLE transactiontype (
trxtype   VARCHAR(5),
trxdesc   VARCHAR(50),
CONSTRAINT transactiontype_trxtype_pk PRIMARY KEY(trxtype)
);

CREATE TABLE itemmaster (
itemcode  VARCHAR(35),
itemdesc  VARCHAR(50),
unit    VARCHAR(15),
stockonhand  INT(11),
stockonorder INT(11),
stockblock  INT(11),
CONSTRAINT itemmaster_itemcode_pk PRIMARY KEY(itemcode)
);


CREATE TABLE productionorder (
prodOrderNo   INT(6) AUTO_INCREMENT,
orderDate   DATE,
factoryID   VARCHAR(10),
productionLine  INT(11),
orderStatus   VARCHAR(15) CHECK ( orderStatus IN ( 'NEW', 'WIP', 'DELIVERED')),
itemcode   VARCHAR(35),
quantity   INT(11),
createdby   VARCHAR(30),
CONSTRAINT productionorder_prodOrderNo_pk PRIMARY KEY(prodOrderNo),
CONSTRAINT productionorder_itemcode_fk FOREIGN KEY(itemcode) REFERENCES itemmaster(itemcode) ON UPDATE CASCADE
);

ALTER TABLE productionorder AUTO_INCREMENT = 300000;

CREATE TABLE inventorytrx (
trxno  INT(6) AUTO_INCREMENT,
trxtype  VARCHAR(5),
trxrefno INT(6),
trxdate  DATE,
itemcode VARCHAR(35),
quantity VARCHAR(35),
createdby VARCHAR(30),
CONSTRAINT inventorytrx_trxno_pk PRIMARY KEY(trxno),
CONSTRAINT inventorytrx_trxtype_fk FOREIGN KEY(trxtype) REFERENCES transactiontype(trxtype) ON UPDATE CASCADE,
CONSTRAINT inventorytrx_itemcode_fk FOREIGN KEY(itemcode) REFERENCES itemmaster(itemcode) ON UPDATE CASCADE,
CONSTRAINT inventorytrx_trxrefno_fk FOREIGN KEY(trxrefno) REFERENCES productionorder(prodOrderNo) ON UPDATE CASCADE
);

ALTER TABLE inventorytrx AUTO_INCREMENT = 100000;

CREATE TABLE replenishmentorder (
repOrderNo  INT(6) AUTO_INCREMENT,
orderDate  DATE,
supplierNo  INT(4),
deliveryDate DATE,
itemcode   VARCHAR(35),
quantity  INT(11),
createdby  VARCHAR(30),
trxtype		VARCHAR(5),
CONSTRAINT replenishmentorder_repOrderNo_pk PRIMARY KEY(repOrderNo),
CONSTRAINT replenishmentorder_supplierNo_fk FOREIGN KEY(supplierNo) REFERENCES supplier(supplierNo) ON UPDATE CASCADE,
CONSTRAINT replenishmentorder_itemcode_fk FOREIGN KEY(itemcode) REFERENCES itemmaster(itemcode) ON UPDATE CASCADE,
CONSTRAINT replenishmentorder_trxtype_fk FOREIGN KEY(trxtype) REFERENCES inventorytrx(trxtype) ON UPDATE CASCADE
);

ALTER TABLE replenishmentorder AUTO_INCREMENT = 400000;
