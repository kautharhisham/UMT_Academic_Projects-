SELECT A.trxno, A.trxdate, A.itemcode, A.quantity
FROM inventorytrx AS A
WHERE NOT EXISTS (SELECT itemcode
				FROM replenishmentorder
                WHERE itemcode = A.itemcode
               ); 