SELECT A.reporderno, A.orderdate, A.itemcode, B.itemdesc
FROM replenishmentorder AS A
INNER JOIN itemmaster AS B
ON A.itemcode = B.itemcode
AND  A.quantity > (SELECT AVG(quantity)
					FROM inventorytrx
                    WHERE itemcode = 'EZ-02145'
                    AND trxtype = 'TRX1')
                    