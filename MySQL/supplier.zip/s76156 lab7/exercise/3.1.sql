SELECT A.orderDate, A.itemcode, B.itemdesc, A.quantity
FROM replenishmentorder AS A
INNER JOIN itemmaster AS B
ON A.itemcode = B.itemcode
AND A.quantity > (SELECT AVG(quantity)
					FROM productionorder
                    WHERE itemcode = 'EC-100PV')
ORDER BY A.orderDate DESC;