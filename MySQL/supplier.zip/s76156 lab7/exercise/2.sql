INSERT INTO itemmaster VALUES('EC-100PV', 'Electronic-Board EC 12 Volts', 'Unit', 3000, 1000, 20);
INSERT INTO itemmaster VALUES('EZ-02145', 'Motor Actuator AC', 'Unit', 3200, 1200, 100);
INSERT INTO itemmaster VALUES('PW-1200W', 'Power Supply 1200 Watt', 'Piece', 1500, 200, 3);
INSERT INTO itemmaster VALUES('RDC-M12WQ', 'Radiator C130', 'Unit', 1200, 500, 0);
INSERT INTO itemmaster VALUES('PRT-10-201', 'Car body 1.5', 'Unit', 1400, 1000, 2);
INSERT INTO itemmaster VALUES('UWC-10020', 'Engine-Block', 'Unit', 2500, 500, 0);
INSERT INTO itemmaster VALUES('DR3413', 'Door for 1.3', 'Piece', 2500, 1000, 10);
INSERT INTO itemmaster VALUES('PRT-210Q', 'Disc Brake', 'PCS', 1300, 250, 2);
INSERT INTO itemmaster VALUES('SK-WS1002', 'Gear Box 1.6', 'Unit', 1200, 200, 1);
INSERT INTO itemmaster VALUES('PRT-SK100', 'Front-Lamp', 'PCS', 1000, 200, 5);

INSERT INTO supplier(supplierName) VALUES ('Electronic GH');
INSERT INTO supplier(supplierName) VALUES ('Automotive Parts Supply');
INSERT INTO supplier(supplierName) VALUES ('ZYZ Manufactured');
INSERT INTO supplier(supplierName) VALUES ('Trend Auto SDN BHD');
INSERT INTO supplier(supplierName) VALUES ('EZ Electric SDN BHD');

INSERT INTO transactiontype VALUES('TRX1', 'Replenishment Order');
INSERT INTO transactiontype VALUES('TRX2', 'Production Order');
INSERT INTO transactiontype VALUES('TRX3', 'Normal Order');
INSERT INTO transactiontype VALUES('TRX4', 'Stock Count');
INSERT INTO transactiontype VALUES('TRX5', 'Adjustment');

INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-06-06', 'Fac 1', 2, 'DELIVERED', 'EC-100PV', 100, 'user02');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-08-02', 'Fac 1', 1, 'DELIVERED', 'PW-1200W', 150, 'user04');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-08-13', 'Fac 2', 3, 'DELIVERED', 'EZ-02145', 50, 'user01');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-08-13', 'Fac 1', 3, 'DELIVERED', 'RDC-M12WQ', 30, 'user02');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-08-23', 'Fac 2', 1, 'DELIVERED', 'PRT-10-201', 100, 'user03');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-09-26', 'Fac 2', 2, 'WIP', 'EC-100PV', 100, 'user01');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-09-28', 'Fac 1', 1, 'DELIVERED', 'PRT-210Q', 600, 'user02');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-09-30', 'Fac 2', 3, 'DELIVERED', 'UWC-10020', 100, 'user03');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-10-08', 'Fac 1', 2, 'DELIVERED', 'EC-100PV', 50, 'user04');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-10-10', 'Fac 1', 3, 'WIP', 'SK-WS1002', 100, 'user01');
INSERT INTO productionorder(orderDate, factoryID, productionLine, orderStatus, itemcode, quantity, createdby)
	VALUES ('2016-10-12', 'Fac 2', 1, 'NEW', 'PRT-SK100', 400, 'user02');    

INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300000, '2016-06-06', 'EC-100PV', 100, 'user02');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300000, '2016-06-08', 'EZ-02145', 200, 'user02');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300001, '2016-08-02', 'PW-1200W', 150, 'user04');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300002, '2016-08-13', 'EZ-02145', 50, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300003, '2016-08-13', 'RDC-M12WQ', 30, 'user02');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300001, '2016-08-13', 'PW-1200W', 1000, 'user04');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300002, '2016-08-13', 'UWC-10020', 300, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300003, '2016-08-15', 'RDC-M12WQ', 300, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300004, '2016-08-23', 'PRT-10-201', 100, 'user03');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300004, '2016-08-23', 'EZ-02145', 300, 'user03');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300005, '2016-08-23', 'PRT-210Q', 1000, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300005, '2016-09-26', 'EC-100PV', 100, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300006, '2016-08-26', 'SK-WS1002', 200, 'user03');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300007, '2016-08-26', 'PRT-SK100', 500, 'user02');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300008, '2016-09-20', 'DR3413', 500, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300009, '2016-09-25', 'RDC-M12WQ', 500, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300006, '2016-09-28', 'PRT-210Q', 600, 'user02');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300007, '2016-09-30', 'UWC-10020', 100, 'user03');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300008, '2016-10-08', 'EC-100PV', 50, 'user04');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300009, '2016-10-10', 'SK-WS1002', 100, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX1', 300010, '2016-10-10', 'EC-100PV', 100, 'user01');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX2', 300010, '2016-10-12', 'PRT-SK100', 400, 'user02');
INSERT INTO inventorytrx(trxtype, trxrefno, trxdate, itemcode, quantity, createdby)
	VALUES ('TRX5', 300000, '2016-10-13', 'SK-WS1002', 1204, 'user03');
    
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-06-08', 1000, '2016-06-15', 'EZ-02145', 200, 'user02');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-13', 1004, '2016-08-17', 'PW-1200W', 100, 'user04');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-13', 1002, '2016-08-25', 'UWC-10020', 300, 'user01');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-15', 1002, '2016-08-20', 'RDC-M12WQ', 300, 'user01');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-23', 1004, '2016-09-04', 'EZ-02145', 300, 'user03');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-23', 1003, '2016-09-01', 'PRT-210Q', 1000, 'user01');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-26', 1001, '2016-09-06', 'SK-WS1002', 200, 'user03');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-08-26', 1001, '2016-09-08', 'PRT-SK100', 500, 'user02');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-09-20', 1003, '2016-10-03', 'DR3413', 500, 'user01');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-09-25', 1002, '2016-10-02', 'RDC-M12WQ', 500, 'user01');
INSERT INTO replenishmentorder(orderDate, supplierNo, deliveryDate, itemcode, quantity, createdby)
VALUES ('2016-10-10', 1004, '2016-10-15', 'EC-100PV', 100, 'user01');