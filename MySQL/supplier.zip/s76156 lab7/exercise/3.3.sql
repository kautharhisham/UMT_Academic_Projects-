SELECT A.prodOrderNo, A.orderDate, A.itemcode, B.itemdesc, A.factoryID,
		A.orderStatus, A.quantity
FROM productionorder AS A
INNER JOIN itemmaster AS B
ON A.itemcode = B.itemcode
AND A.orderDate IN (SELECT orderDate
					FROM replenishmentorder
                    WHERE quantity = (SELECT MAX(quantity)
										FROM replenishmentorder)
					);