SELECT A.conferenceid, A.conferencename, A.conf_year, COUNT(B.conferenceid) AS NoOfSession
FROM conference AS A
INNER JOIN eventdetails AS B ON A.conferenceid = B.conferenceid
WHERE B.organiserid = 100
GROUP BY A.conferenceid, A.conferencename
HAVING A.conf_year BETWEEN 2003 AND 2015;