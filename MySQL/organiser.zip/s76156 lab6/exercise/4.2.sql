SELECT A.company, SUM(B.fees) AS totalfeespaid
FROM participant AS A, conferencedetails AS B, conference AS C
WHERE A.participantid = B. participantid
AND B.conferenceid = C.conferenceid
AND C.conf_year IN (2008, 2010, 2016)
GROUP BY A.company