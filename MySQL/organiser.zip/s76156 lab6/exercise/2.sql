DROP DATABASE IF EXISTS lab6;
CREATE DATABASE lab6;
USE lab6;

CREATE TABLE organiser(
organiserid			INT,
organisername		VARCHAR(50),
address				VARCHAR(60),
postcode			INT(5),
state				VARCHAR(30),
contactperson		VARCHAR(30),
contactno			VARCHAR(15),
emailaddress		VARCHAR(35),
CONSTRAINT organiser_organiserid_pk PRIMARY KEY(organiserid)
);

CREATE TABLE participant(
participantid		INT AUTO_INCREMENT,
participantname		VARCHAR(50),
company				VARCHAR(60),
designation			VARCHAR(30),
CONSTRAINT participant_participantid_pk PRIMARY KEY(participantid)
);

ALTER TABLE participant AUTO_INCREMENT = 10001;

CREATE TABLE venue(
venueid				INT,
venuename			VARCHAR(50),
addr_street			VARCHAR(60),
addr_city			VARCHAR(30),
addr_postcode		INT(5),
addr_state			VARCHAR(30),
CONSTRAINT venue_venueid_pk PRIMARY KEY(venueid)
);

CREATE TABLE conference(
conferenceid		VARCHAR(15),
conferencename		VARCHAR(50),
venueid				INT,
conferencedate		DATE,
theme				VARCHAR(60),
conf_year			INT(4),
CONSTRAINT conference_conferenceid_pk PRIMARY KEY(conferenceid),
CONSTRAINT conference_venueid_fk FOREIGN KEY(venueid) REFERENCES venue(venueid) ON UPDATE CASCADE
);

CREATE TABLE conferencedetails(
conferenceid		VARCHAR(15) NOT NULL,
participantid		INT NOT NULL,
fees				NUMERIC(7,2),
CONSTRAINT conf_part_pk UNIQUE(conferenceid, participantid),
CONSTRAINT conferencedetails_conferenceid_fk FOREIGN KEY(conferenceid) REFERENCES conference(conferenceid) ON UPDATE CASCADE,
CONSTRAINT conferencedetails_participantid_fk FOREIGN KEY(participantid) REFERENCES participant(participantid) ON UPDATE CASCADE
);

CREATE TABLE eventdetails(
sessionid			INT,
conferenceid		VARCHAR(15),
sessionname			VARCHAR(50),
organiserid			INT,
CONSTRAINT eventdetails_sessionid_pk PRIMARY KEY(sessionid),
CONSTRAINT eventdetails_conferenceid_fk FOREIGN KEY(conferenceid) REFERENCES conference(conferenceid)  ON UPDATE CASCADE,
CONSTRAINT eventdetails_organiserid_fk FOREIGN KEY(organiserid) REFERENCES organiser(organiserid) ON UPDATE CASCADE
);
