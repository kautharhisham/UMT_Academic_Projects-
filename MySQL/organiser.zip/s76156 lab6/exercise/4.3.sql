SELECT A.venuename, COUNT(B.conferenceid) AS no_of_conference
FROM venue AS A
INNER JOIN conference AS B
ON A.venueid = B.venueid
GROUP BY A.venuename
HAVING COUNT(B.conferenceid) > 1;