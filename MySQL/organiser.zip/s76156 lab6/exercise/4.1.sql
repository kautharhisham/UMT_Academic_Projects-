SELECT A.organisername, C.conferenceid, COUNT(*) AS NoOfParticipants
FROM organiser AS A
INNER JOIN eventdetails AS B
ON A.organiserid = B.organiserid
INNER JOIN conference AS C
ON B.conferenceid = C.conferenceid
GROUP BY A.organisername, C.conferenceid
ORDER BY A.organisername ASC;