SELECT A.participantid, A.participantname, COUNT(B.conferenceid) AS FrequentAttend
FROM participant AS A
INNER JOIN conferencedetails AS B
USING (participantid)
INNER JOIN conference AS C
USING (conferenceid)
INNER JOIN venue AS D
ON C.venueid = D.venueid
AND D.addr_city IN ('Kuala Lumpur', 'Langkawi','Penang')
GROUP BY A.participantid, A.participantname
ORDER BY FrequentAttend DESC;