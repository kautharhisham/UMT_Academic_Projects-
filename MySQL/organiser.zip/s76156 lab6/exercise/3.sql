INSERT INTO organiser VALUES (100, 'ABC Research Corporation', 'No. 120, Persiaran Bukit Jalil',
57000, 'Kuala Lumpur', 'Abdul Rahim', '03-5565050', 'rahim@abc.com.my');
INSERT INTO organiser VALUES (200, 'XYZ Development Sdn Bhd', '1/2 Lebuh ICT, Seksyen 7',
41300, 'Shah Alam', 'Mohd Azman', '03-5125639', 'azman@xyz.com.my');
INSERT INTO organiser VALUES (300, 'YNR Research Institute', 'No. 135, Persiaran Bukit Jalil',
57000, 'Kuala Lumpur', 'Ahmad Majid', '03-6527244', 'majid@yahoo.com.my');

INSERT INTO participant(participantname, company, designation) VALUES('Zulkifli Ali', 'Tunas Sdn Bhd', 'Researcher');
INSERT INTO participant(participantname, company, designation)	VALUES('Nik Amira Nik Hashim', 'Zeon Research Bhd', 'Principal Researcher');
INSERT INTO participant(participantname, company, designation)	VALUES('Nur Adha', 'Prima Electronic Sdn Bhd', 'System Engineer');
INSERT INTO participant(participantname, company, designation)	VALUES('Ahmad Azim', 'Zeon Research Bhd', 'Researcher');
INSERT INTO participant(participantname, company, designation)	VALUES('Halim Babas', 'GZ R&D Sdn Bhd', 'Software Engineer');
    
INSERT INTO venue VALUES (1001, 'KLCC Convention Centre', 'Jln Pinang', 'Kuala Lumpur', 51500, 'W.Persekutuan');
INSERT INTO venue VALUES (1002, 'Langkawi Int. Convention Centre', 'Jln Dato Syed Omar', 'Langkawi', 07000, 'Kedah');
INSERT INTO venue VALUES (1003, 'Park Royal Penang Resort', 'Jln Batu Ferringhi', 'Batu Ferringhi', 11100, 'Penang');
INSERT INTO venue VALUES (1004, 'The Royale Bintang Resort & Spa Seremban', 'Jalan Sato A.S Dawood', 'Seremban', 70100, 'negeri Sembilan');
INSERT INTO venue VALUES (1005, 'PJ Hilton Hotel', 'Jalan Persiaran', 'Petaling Jaya', 48600, 'Selangor');

INSERT INTO conference VALUES ('ICC2006', 'International Computing Conference', 1001, '2006-05-25', 'Computing for People', 2006);
INSERT INTO conference VALUES ('Cos2008', 'Conference of Software', 1002, '2008-09-15', 'Software As Enabler', 2008);
INSERT INTO conference VALUES ('DSC2010', 'Data Science Conference', 1005, '2010-09-15', 'Big Data for Future', 2010);
INSERT INTO conference VALUES ('ICS2012', 'International Computer Science Conference', 1003, '2012-06-15', 'Agile Computer Science', 2012);
INSERT INTO conference VALUES ('ECC2014', 'Embedded Computing Conference', 1004, '2014-09-02', 'Embedded Computing for Better Life', 2014);
INSERT INTO conference VALUES ('IoTC2016', 'Embedded Computing Conference', 1001, '2016-11-28', 'IoT The Next Technology', 2016);

INSERT INTO conferencedetails VALUES ('ICC2006', 10001, 3000.00);
INSERT INTO conferencedetails VALUES ('ICC2006', 10002, 3000.00);
INSERT INTO conferencedetails VALUES ('ICC2006', 10003, 6000.00);
INSERT INTO conferencedetails VALUES ('Cos2008', 10002, 2500.00);
INSERT INTO conferencedetails VALUES ('Cos2008', 10003, 2500.00);
INSERT INTO conferencedetails VALUES ('Cos2008', 10004, 2500.00);
INSERT INTO conferencedetails VALUES ('DSC2010', 10001, 4000.00);
INSERT INTO conferencedetails VALUES ('DSC2010', 10003, 4000.00);
INSERT INTO conferencedetails VALUES ('DSC2010', 10005, 8000.00);
INSERT INTO conferencedetails VALUES ('ICS2012', 10002, 2800.00);
INSERT INTO conferencedetails VALUES ('ICS2012', 10004, 2800.00);
INSERT INTO conferencedetails VALUES ('ECC2014', 10001, 3200.00);
INSERT INTO conferencedetails VALUES ('ECC2014', 10003, 3200.00);
INSERT INTO conferencedetails VALUES ('ECC2014', 10005, 3200.00);
INSERT INTO conferencedetails VALUES ('IoTC2016', 10001, 6000.00);
INSERT INTO conferencedetails VALUES ('IoTC2016', 10002, 6000.00);
INSERT INTO conferencedetails VALUES ('IoTC2016', 10004, 12000.00);
INSERT INTO conferencedetails VALUES ('IoTC2016', 10005, 6000.00);

INSERT INTO eventdetails VALUES (1, 'ICC2006', 'Session 1', 100);
INSERT INTO eventdetails VALUES (2, 'ICC2006', 'Session 2', 100);
INSERT INTO eventdetails VALUES (3, 'ICC2006', 'Session 3', 100);
INSERT INTO eventdetails VALUES (4, 'Cos2008', 'Session A', 200);
INSERT INTO eventdetails VALUES (5, 'Cos2008', 'Session B', 200);
INSERT INTO eventdetails VALUES (6, 'DSC2010', 'Session A1', 300);
INSERT INTO eventdetails VALUES (7, 'DSC2010', 'Session A2', 300);
INSERT INTO eventdetails VALUES (8, 'DSC2010', 'Session A3', 300);
INSERT INTO eventdetails VALUES (9, 'ICS2012', 'Session 1', 100);
INSERT INTO eventdetails VALUES (10, 'ICS2012', 'Session 2', 100);
INSERT INTO eventdetails VALUES (11, 'ECC2014', 'Session X1', 200);
INSERT INTO eventdetails VALUES (12, 'ECC2014', 'Session X2', 200);
INSERT INTO eventdetails VALUES (13, 'IoTC2016', 'Session A', 300);
INSERT INTO eventdetails VALUES (14, 'IoTC2016', 'Session B', 300);
INSERT INTO eventdetails VALUES (15, 'IoTC2016', 'Session C', 300);