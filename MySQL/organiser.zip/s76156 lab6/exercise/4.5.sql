SELECT A.conferenceid, A.conferencename, MAX(B.fees) AS HighestPaid
FROM conference AS A
INNER JOIN conferencedetails AS B
USING (conferenceid)
GROUP BY A.conferenceid, A.conferencename
HAVING A.conferenceid IN ('DSC2010', 'IoTC2016');