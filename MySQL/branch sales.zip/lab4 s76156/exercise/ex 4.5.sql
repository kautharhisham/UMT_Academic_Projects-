SELECT slsid, slsname, slsbranch
FROM salesman
WHERE slsname LIKE '%Mohd%';