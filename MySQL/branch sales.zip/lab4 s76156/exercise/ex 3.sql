INSERT INTO branch VALUES(101, 'ABC Venture Shah Alam', 'Shah Alam', 'Selangor');
INSERT INTO branch VALUES(102, 'ABC Venture Klang', 'Klang', 'Selangor');
INSERT INTO branch VALUES(103, 'ABC Venture Sepang', 'Sepang', 'Selangor');
INSERT INTO branch VALUES(104, 'ABC Venture SS/15', 'Petaling Jaya', 'Selangor');
INSERT INTO branch VALUES(111, 'ABC Venture Maluri', 'Cheras', 'Kuala Lumpur');
INSERT INTO branch VALUES(112, 'ABC Venture Maluri', 'Bukit Damansara', 'Kuala Lumpur');
INSERT INTO branch VALUES(201, 'ABC Venture Ipoh', 'Ipoh', 'Perak');
INSERT INTO branch VALUES(205, 'ABC Venture Georgetown', 'Georgetown', 'Penang');
INSERT INTO branch VALUES(701, 'ABC Venture Bukit Besar', 'K. Terengganu', 'Terengganu');
INSERT INTO branch VALUES(707, 'ABC Venture Kota Baharu', 'Kota Baharu', 'Kelantan');

INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Rahimi Mohsin', '1991-05-12', 103);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Andrew Lee', '1988-07-10', 205);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Nurlina Abbas', '1990-03-28', 102);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Mohd Rahim Izuan', '1985-12-25', 707);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Adam Abdullah', '1979-03-17', 112);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Vinaswari a/p Ramesh', '1992-09-02', 104);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Siti Aminah Kassim', '1990-10-16', 701);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Zainal Hakimi', '1987-04-08', 112);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Mohd Azlan Wahid', '1988-01-27', 101);
INSERT INTO salesman(slsname, slsdob, slsbranch) VALUES('Ng Wee Wern', '1990-05-15', 111);

INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-26', 81880.00, 2006);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-27', 87580.00, 2001);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-27', 79300.00, 2002);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-28', 120900.00, 2000);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-28', 84600.00, 2008);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-28', 81880.00, 2009);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-29', 71538.00, 2003);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-30', 144800.00, 2007);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-11-30', 92000.00, 2002);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-12-02', 78000.00, 2005);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-12-02', 102200.00, 2006);
INSERT INTO sales(sdate, samount, slsid) VALUES('2015-12-03', 89000.00, 2004);

