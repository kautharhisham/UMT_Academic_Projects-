CREATE INDEX salesman_slsname_ind
ON salesman(slsname);
