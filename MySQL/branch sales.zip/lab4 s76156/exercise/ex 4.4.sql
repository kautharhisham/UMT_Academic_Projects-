CREATE VIEW vsalesinfo AS
SELECT slsid, sdate
FROM sales;

SELECT *
FROM vsalesinfo;