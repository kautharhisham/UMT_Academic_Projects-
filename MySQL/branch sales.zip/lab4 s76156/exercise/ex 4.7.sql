UPDATE salesman
SET slsname = 'Fairuz Nasaruddin'
WHERE slsid = 2007
AND slsbranch = 112;

SELECT *
FROM salesman
WHERE slsid = 2007;