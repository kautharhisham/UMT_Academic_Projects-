CREATE TABLE branch (
brncode		INT(3),
brnname		VARCHAR(50) NOT NULL,
brncity		VARCHAR(30),
brnstate	VARCHAR(30),
CONSTRAINT branch_brncode_pk PRIMARY KEY(brncode)
);

CREATE TABLE salesman (
slsid		INT(6) AUTO_INCREMENT,
slsname		VARCHAR(50) NOT NULL,
slsdob		DATE,
slsbranch	INT(3) NOT NULL,
CONSTRAINT salesman_slsid_pk PRIMARY KEY(slsid),
CONSTRAINT salesman_slsbranch_fk FOREIGN KEY(slsbranch) REFERENCES branch(brncode) ON UPDATE CASCADE
);

ALTER TABLE salesman AUTO_INCREMENT = 2000;

CREATE TABLE sales (
sreference		INT(8) AUTO_INCREMENT,
sdate 			DATE NOT NULL,
sAmount			DECIMAL(9,2),
slsid			INT(5) NOT NULL,
CONSTRAINT sales_sreference_pk PRIMARY KEY(sreference),
CONSTRAINT sales_slsid_fk FOREIGN KEY(slsid) REFERENCES salesman(slsid) ON UPDATE CASCADE
);

ALTER TABLE sales AUTO_INCREMENT = 900000;