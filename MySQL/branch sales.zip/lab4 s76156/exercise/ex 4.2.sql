CREATE TABLE KLBranch AS
SELECT brncode, brnname, brncity
FROM branch
WHERE brnstate = 'Kuala Lumpur';

SELECT *
FROM KLBranch;