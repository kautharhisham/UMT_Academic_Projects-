SELECT *
FROM sales;

UPDATE sales
SET samount = 55000.00
WHERE sreference = 900006;
