SELECT sreference, sdate, samount
FROM sales
WHERE sdate = '2015-11-28'
AND samount > 75000.00;