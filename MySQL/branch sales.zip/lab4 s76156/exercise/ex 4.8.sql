CREATE USER user04@localhost IDENTIFIED BY 'u04@ser';

GRANT SELECT ON mylab4.sales
TO user04@localhost;