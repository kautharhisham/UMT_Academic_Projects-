SELECT sreference, sdate, samount
FROM sales
WHERE sdate LIKE '%_____12%';