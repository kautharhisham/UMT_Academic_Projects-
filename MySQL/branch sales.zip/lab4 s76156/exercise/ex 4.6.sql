SELECT brncode, brnname, brncity
FROM branch
WHERE brncity LIKE 'K%';